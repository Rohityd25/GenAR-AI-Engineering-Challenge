# GenAR AI Engineering Challenge: Pharmacovigilance Periodic Safety Reporting System (Version 0 & Version 1)

> **Core System Principle:** The report can only say what the data supports. Every single figure, count, percentage, and date is computed deterministically in pure Python before the LLM is invoked. The LLM's role is strictly scoped to neutral regulatory prose synthesis based *only* on pre-computed evidence packets.

---

## 1. Quickstart & How to Run

### Setup
```bash
# 1. Clone repository / navigate to project root
cd GenAi_Assignment

# 2. Install dependencies (standard requirements)
pip install pandas openpyxl pyyaml jinja2 pydantic markdown python-docx reportlab pytest
```

### One-Command Full Report Regeneration
```bash
# Generates PADER Markdown, HTML, and Word DOCX reports + runs automated 100% grounding verification:
python main.py --input "C:\Users\ROHIT YADAV\Downloads\Bisoprolol_icsr_sample_1068rows.xlsx" --config configs/pader_config.yaml --output-dir output
```

### Run Unit & Integration Tests
```bash
python -m pytest tests/ -v
```

### Interactive Human Review CLI
```bash
python review.py --store output/review_store.json --config configs/pader_config.yaml
```

---

## 2. End-to-End System Architecture

```mermaid
flowchart TD
    subgraph 1. Data Ingestion & Hygiene
        A[Raw ICSR File: CSV / Excel\n1,068 rows, 67 columns] --> B[src.data_loader: ICSRDataLoader]
        B --> C[Case-level Deduplication\n1,024 Unique safetyreportid]
        B --> D[Derived Reporting Period\nmin / max receivedate: 2024-12-27 to 2025-12-26]
    end

    subgraph 2. Deterministic Analysis Layer (Pure Python)
        C & D --> E[src.analyses: AnalysisRegistry]
        E --> F1[total_cases]
        E --> F2[serious_vs_nonserious]
        E --> F3[breakdown_by_age]
        E --> F4[breakdown_by_sex]
        E --> F5[breakdown_by_country]
        E --> F6[top_reactions / top_serious]
        E --> F7[outcomes_summary]
        E --> F8[trend_over_time]
        E --> F9[alert_cases_summary]
        E --> F10[case_listing]
        F1 & F2 & F3 & F4 & F5 & F6 & F7 & F8 & F9 & F10 --> G[(Pre-Computed Analyses JSON\noutput/analyses.json)]
    end

    subgraph 3. Declarative Configuration & Packet Assembly
        H[configs/pader_config.yaml\nconfigs/psur_config.yaml] --> I[src.config: ReportConfig]
        G & I --> J[src.packet_assembler: PacketAssembler]
        J --> K[(Scoped Context Packets JSON\n1 Isolated Packet per Section)]
    end

    subgraph 4. Controlled Section Generation & Audit
        K --> L[prompts/section_prompt.txt\nJinja2 Parameterized Prompt]
        L --> M[src.llm_generator: LLMGenerator\nOpenAI / Gemini / Anthropic / Deterministic Fallback]
        M --> N[(Traceability Audit Log\noutput/prompt_audit_log.jsonl)]
        M --> O[Generated Section Drafts]
    end

    subgraph 5. Governance & Multi-Format Assembly
        O --> P[src.reviewer: ReviewStore & CLI\npending_review / approved / flagged]
        P --> Q[src.report_assembler: ReportAssembler]
        Q --> R1[Markdown Report\nreport_output.md]
        Q --> R2[HTML Report\nreport_output.html]
        Q --> R3[Word Document\nreport_output.docx]
    end

    subgraph 6. Automated Grounding Evaluation
        K & R1 --> S[src.evaluator: GroundingEvaluator]
        S --> T[100% Numeric Traceability Audit\nPrecision = 1.0, Ungrounded = 0]
        S --> U[(Evaluation Report JSON\noutput/evaluation_report.json)]
    end
```

---

## 3. Where AI is Used vs. Deterministic Code (And Why)

| Pipeline Stage | Implementation | Rationale |
| :--- | :--- | :--- |
| **Data Ingestion & Deduplication** | Pure Python (`pandas`) | Case vs. reaction counting must be mathematically exact (1,024 cases vs 1,068 rows). |
| **Reporting Period Derivation** | Pure Python (`pandas`) | Boundary calculation (`min`/`max` `receivedate`) cannot be guessed or hardcoded. |
| **Statistical & Demographic Aggregations** | Pure Python (`src/analyses.py`) | Seriousness breakdown, age normalizations, sex/country counts must have zero arithmetic error. |
| **Context Packet Isolation** | Pure Python (`src/packet_assembler.py`) | Context engineering: strictly isolates evidence so each section LLM only receives what it is authorized to see. |
| **Regulatory Prose Drafting** | Scoped LLM Calls (`src/llm_generator.py`) | AI excels at phrasing pre-computed JSON facts into neutral regulatory sentences complying with ICH E2C / FDA guidelines. |
| **Human Review & Approval Store** | Pure Python (`src/reviewer.py`) | Audit-logged compliance gate ensuring human oversight before publication. |
| **Document Assembly (MD/HTML/DOCX)**| Pure Python (`src/report_assembler.py`) | Deterministic concatenation of approved sections in precise regulatory sequence. |
| **Grounding Evaluation** | Pure Python (`src/evaluator.py`) | Automated regex and token matching to audit that every number in the output exists in the evidence packet. |

---

## 4. Exact Prompts and Context Templates

The pipeline uses a single parameterized Jinja2 prompt template located at [`prompts/section_prompt.txt`](prompts/section_prompt.txt):

```text
You are a Senior Pharmacovigilance Regulatory Medical Writer preparing a periodic safety report in compliance with ICH E2C and US FDA 21 CFR 314.80 guidelines.

Your task is to draft the content for the following section:
SECTION NAME: {{ section_name }}
REPORT TYPE: {{ report_type }}
PRODUCT: {{ product_name }}
REPORTING PERIOD: {{ reporting_period_start }} to {{ reporting_period_end }}

======================================================================
MANDATORY REGULATORY WRITING RULES:
1. STRICT NUMERIC GROUNDING: Every number, count, percentage, or date in your output MUST be directly sourced from the PRE-COMPUTED EVIDENCE PACKET below. NEVER perform mental math, NEVER estimate figures, and NEVER aggregate or infer new numbers.
2. ZERO HALLUCINATIONS: If an analysis or field is absent or marked unavailable in the evidence packet (such as System Organ Class mappings, Reference Safety Information/CCDS, or History of Actions), explicitly state that it was not available in the dataset. Do NOT fabricate or assume values.
3. REGULATORY NEUTRALITY: Maintain an objective, factual, and neutral regulatory tone. Never write speculative conclusions such as "no safety concerns were identified" or "the benefit-risk profile remains unchanged" unless supported directly by an explicit evidence signal.
4. OBSERVED VS. DERIVED: Clearly distinguish between observed raw counts (e.g. unnested MedDRA PT mentions) and derived aggregates (e.g. deduplicated unique safety cases).
5. FORMATTING: Produce clean GitHub-flavored Markdown with structured subsections, Markdown tables where relevant, and clear narrative summaries.

======================================================================
SECTION INSTRUCTIONS:
{{ section_instructions }}

======================================================================
DATA HEALTH & REGULATORY BOUNDARIES:
- SOC Available: {{ data_health.soc_available }} ({{ data_health.soc_note }})
- RSI / CCDS Available: {{ data_health.rsi_ccds_available }} ({{ data_health.rsi_note }})
- History of Actions Available: {{ data_health.history_of_actions_available }} ({{ data_health.history_of_actions_note }})
- Occur vs. Reporter Country Divergence: {{ data_health.country_divergence_cases }} cases

======================================================================
PRE-COMPUTED EVIDENCE PACKET (JSON):
{{ evidence_packet_json }}

======================================================================
Generate the regulatory text for "{{ section_name }}". Output clean Markdown directly:
```

---

## 5. How the System Stays Grounded

1. **Pre-Computed Fact Confinement:** The model is never given raw data, tables, or access to external tools during drafting. It receives a read-only JSON packet of pre-calculated metrics.
2. **One Call per Section:** Whole-report generation invites cross-section drift and token degradation. Section-scoped generation ensures high attention and zero cross-contamination.
3. **Explicit Boundary Signaling:** When data is absent (e.g., CCDS, SOC, History of Actions), the packet explicitly declares `available: false` and the prompt instructs the model to state the gap plainly rather than inferring data.
4. **Automated Numeric Verification Gate:** The evaluator (`src/evaluator.py`) automatically extracts every numeric figure (integers, floats, percentages, dates) and verifies that it is a subset of the numbers present in the context packet.

---

## 6. How We Evaluate at Scale (1,000 Generated Reports, Not One)

When scaling to evaluate 1,000 generated periodic reports across a multi-product enterprise portfolio:

```
[1,000 Raw Datasets] 
    → Automated Pipeline Generation 
    → [1,000 Report JSONs + Evidence Packets]
    → TIER 1: 100% Automated Grounding Audit (Regex Token Matcher, Precision = 1.0 Gate)
    → TIER 2: Regulatory Compliance Linter (Prohibited assertion detection & structural conformance)
    → TIER 3: Cross-Run Stability & Regeneration Diffs (Variance testing at temperature = 0.0 vs 0.2)
    → TIER 4: Stratified Clinical Human Sampling (Sample 5-10% of high-complexity reports for medical review sign-off)
```

1. **Automated Numeric Extraction Gate:** 100% of all 1,000 reports undergo regex-based numeric token auditing. Any report with an ungrounded statistic ($Precision < 100\%$) is automatically rejected by CI/CD.
2. **Regulatory Linter & Prohibited Phrase Detection:** Automated text linters flag banned speculative phrases (e.g., *"proves causation"*, *"no safety concerns were found"*).
3. **Statistical Temperature Variance Diffs:** Generate 3 stochastic variations per section and run semantically-constrained diffing to ensure critical regulatory claims remain invariable.
4. **Risk-Stratified Human Review:** A sampling algorithm routes reports with rare high-severity outcomes (e.g., high death count, unexpected pediatric exposure) to senior safety physicians.

---

## 7. Known Limitations & Explicit Dataset Gaps

1. **No System Organ Class (SOC) Mapping:** The dataset only contains `patient_reaction_reactionmeddrapt` (MedDRA Preferred Term). In adherence to the brief, our system reports strictly at the PT level and explicitly states that SOC grouping is unavailable.
2. **No Reference Safety Information (CCDS / SmPC):** Without approved product labeling data, **expectedness / labeledness** cannot be calculated from ICSR listings alone. The pipeline explicitly notes this limitation rather than fabricating an unlabelled/labelled split.
3. **No History-of-Actions Data:** No regulatory action records were provided. The report section explicitly declares this data gap.
4. **Deduplication Methodology:** Case-level counts use deduplicated `safetyreportid` (1,024 unique cases); reaction-level counts unnest all comma-delimited MedDRA PTs (3,648 mentions).
5. **Geographic Divergence:** `occurcountry` was selected as the primary geographic field; 8 cases showed minor divergence with `primarysource_reportercountry`, which is documented in the case demographics section.

---

## 8. "The Real Test" — Generalization to PSUR / PBRER / DSUR / CSR

The true test of an AI architecture is whether generating a new report type requires rewriting code or simply modifying declarative configuration.

### What Survives 100% Unmodified:
- `src/data_loader.py` (Universal ICSR ingestion and deduplication engine)
- `src/packet_assembler.py` (Report-agnostic context packet isolation)
- `src/llm_generator.py` (Multi-provider LLM caller and audit logger)
- `src/reviewer.py` (Human approval and review tracking store)
- `src/report_assembler.py` (Multi-format assembly engine for MD, HTML, DOCX)
- `src/evaluator.py` (Automated numeric grounding verifier)

### What Changes:
- **Only a new YAML configuration file** (e.g. `configs/psur_config.yaml` or `configs/dsur_config.yaml`) defining the new section titles, required analysis keys, and specific regulatory instructions.
- If a new report type requires specialized math (e.g., Disproportionality PRR/ROR for PSUR, or Exposure Adjustments for CSR), a new pure Python function is decorated with `@AnalysisRegistry.register("analysis_name")` in `src/analyses.py`.

*Proof of Generalization:* A complete working PSUR configuration is included in [`configs/psur_config.yaml`](configs/psur_config.yaml) and can be executed immediately:
```bash
python main.py --config configs/psur_config.yaml --output-dir output/psur
```

---

## 9. Data Usage Notice Acknowledgement

In compliance with `DATA_USAGE_NOTICE.pdf`:
- The dataset `Bisoprolol_icsr_sample_1068rows.xlsx` is utilized strictly for the purpose of this technical evaluation.
- No commercial use or external redistribution of the dataset is made.
- Raw CSV/Excel data files are excluded from submission packages.
